# Wisp Distance

[ENG]

The Wisp Distance mod will show the distance in meters in the buff text when you equip the wisp light in your accesory slot. If you use any other mods that change this value, it will be updated in the text.

[ESP]

El mod Wisp Distance te mostrará la distancia en metros en el texto del beneficio cuando te equipes la Luz de Wisp en tu ranura de accesorio. Si usas otros mods que cambian este valor, se reflejará en el texto.

# About myself

DISCORD: Turbero (Turbero#3465)

STEAM: https://steamcommunity.com/id/turbero

For any concerns or doubts, find me in the Hijos de Freyja Team Discord or in my own channel (click on icons):

[ENG/ESP]

<a href="https://discord.gg/hijos-de-freyja-818547021777993748"><img src="https://i.imgur.com/nWZ5kGc.png"></a>

[ESP]

<a href="https://discord.gg/JKQR3EWRbU"><img src="https://i.imgur.com/WvOS4CK.png"></a>&nbsp;&nbsp;
<a href="https://discord.gg/y67YeVw62K"><img src="https://i.imgur.com/A9b3EGB.png"></a>

[ESP]

Si quieres disfrutar de este mod y muchos más, únete a la comunidad de Hijos de Freyja =) : https://discord.gg/hijos-de-freyja-818547021777993748

O pregúntame en mis canales personales:

* Turbeheim: https://discord.gg/JKQR3EWRbU
* Más Turbero: https://discord.gg/y67YeVw62K

[ENG]

![](https://i.imgur.com/A4rTZmT.png)

[ESP]

![](https://i.imgur.com/cxfHO9b.png)