### CHANGELOG

## 1.0.1

* Fixing icon, sorry!

## 1.0.0

Initial version